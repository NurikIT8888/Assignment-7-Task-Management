public class HomeworkTask implements Task {
}

public class MeetingTask implements Task {
}

public class ShoppingTask implements Task {
}
